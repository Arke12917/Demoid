/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


using System;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Loads a music file for playback.  Returns the music ID.")]
	public class ANAMusicLoad : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The path to the music file, relative to Assets\\StreamingAssets.")]
		public FsmString AudioFile;

		[Tooltip("If true, Audio File is relative to Application.persistentDataPath.  If false, it is relative to Assets\\StreamingAssets.")]
		[RequiredField]
		public FsmBool UsePersistentDataPath = false;

		[Tooltip("If true, the file is loaded asynchronously and the action immediately finishes.  Use Loaded Event to know when the load has completed.  If false, the action will not finish until the load has completed.")]
		[RequiredField]
		public FsmBool LoadAsync = false;

		[Tooltip("An event to call when the load has completed, typically used with Load Async.")]
		public FsmEvent LoadedEvent;

		[Tooltip("If true, the music will continue playing when the game is not active.  If false, the music will be paused when the game is not active and resumed when it becomes active again.")]
		[RequiredField]
		public FsmBool PlayInBackground = false;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the loaded music file.  Use this to pause, change volume, etc.  If Loaded Event is called, this variable will receive the loaded music ID again.")]
		[RequiredField]
		public FsmInt MusicID;


		public override void Reset()
		{
			AudioFile = null;
			UsePersistentDataPath = false;
			LoadAsync = false;
			MusicID = null;
		}
		

		public override void OnEnter()
		{
			Action<int> callback = null;
			if (LoadedEvent != null)
				callback = OnLoaded;
			MusicID.Value = ANAMusic.load(AudioFile.Value, UsePersistentDataPath.Value, LoadAsync.Value, callback, PlayInBackground.Value);
			Finish();
		}


		public void OnLoaded(int musicID)
		{
			MusicID.Value = musicID;
			Fsm.Event(LoadedEvent);
		}
	}
}
