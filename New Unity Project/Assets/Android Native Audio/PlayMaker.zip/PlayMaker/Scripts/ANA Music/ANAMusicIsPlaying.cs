/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Checks whether the music is playing.")]
	public class ANAMusicIsPlaying : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("The event to call if the music is playing.")]
		public FsmEvent PlayingEvent;

		[Tooltip("The event to call if the music is not playing.")]
		public FsmEvent NotPlayingEvent;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("True if the music is currently playing, false otherwise.")]
		public FsmBool IsPlaying;


		public override void Reset()
		{
			MusicID = null;
			PlayingEvent = null;
			NotPlayingEvent = null;
			IsPlaying = null;
		}
		

		public override void OnEnter()
		{
			var _isLooping = ANAMusic.isPlaying(MusicID.Value);
			if (IsPlaying != null)
				IsPlaying.Value = _isLooping;

			if (_isLooping && PlayingEvent != null)
				Fsm.Event(PlayingEvent);
			else if (!_isLooping && NotPlayingEvent != null)
				Fsm.Event(NotPlayingEvent);

			Finish();
		}
	}
}
