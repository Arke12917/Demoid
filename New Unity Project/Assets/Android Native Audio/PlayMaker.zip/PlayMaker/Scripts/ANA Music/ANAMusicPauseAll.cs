/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Pauses all currently playing music.  Use the Resume All action to resume only music that was paused with Pause All.")]
	public class ANAMusicPauseAll : FsmStateAction
	{
		[UIHint(UIHint.Description)]
		public string Description = "Pauses all currently playing music.  Use the Resume All action to resume only music that was paused with Pause All.";


		public override void OnEnter()
		{
			ANAMusic.pauseAll();
			Finish();
		}
	}
}
