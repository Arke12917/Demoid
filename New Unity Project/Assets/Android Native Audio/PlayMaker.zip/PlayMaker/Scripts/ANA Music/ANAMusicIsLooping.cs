/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Checks whether the music is looping or non-looping.")]
	public class ANAMusicIsLooping : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("The event to call if the music is looping.")]
		public FsmEvent LoopingEvent;

		[Tooltip("The event to call if the music is not looping.")]
		public FsmEvent NotLoopingEvent;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("True if the music is currently looping, false otherwise.")]
		public FsmBool IsLooping;


		public override void Reset()
		{
			MusicID = null;
			LoopingEvent = null;
			NotLoopingEvent = null;
			IsLooping = null;
		}
		

		public override void OnEnter()
		{
			var _isLooping = ANAMusic.isLooping(MusicID.Value);
			if (IsLooping != null)
				IsLooping.Value = _isLooping;

			if (_isLooping && LoopingEvent != null)
				Fsm.Event(LoopingEvent);
			else if (!_isLooping && NotLoopingEvent != null)
				Fsm.Event(NotLoopingEvent);

			Finish();
		}
	}
}
