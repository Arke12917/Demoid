/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Seeks to specified time position.")]
	public class ANAMusicSeekTo : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("The offset in milliseconds from the start to seek to.")]
		[RequiredField]
		public FsmInt Milliseconds;


		public override void Reset()
		{
			MusicID = null;
			Milliseconds = null;
		}
		

		public override void OnEnter()
		{
			ANAMusic.seekTo(MusicID.Value, Milliseconds.Value);
			Finish();
		}
	}
}
