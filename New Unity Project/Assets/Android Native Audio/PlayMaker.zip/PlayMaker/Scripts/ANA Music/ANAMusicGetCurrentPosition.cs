/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Gets the current playback position.")]
	public class ANAMusicGetCurrentPosition : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The current position in milliseconds.")]
		[RequiredField]
		public FsmInt CurrentPosition;


		public override void Reset()
		{
			MusicID = null;
			CurrentPosition = null;
		}
		

		public override void OnEnter()
		{
			CurrentPosition.Value = ANAMusic.getCurrentPosition(MusicID.Value);
			Finish();
		}
	}
}
