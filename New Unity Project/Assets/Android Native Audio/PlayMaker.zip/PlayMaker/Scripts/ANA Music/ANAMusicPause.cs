/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Pauses playback.")]
	public class ANAMusicPause : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;


		public override void Reset()
		{
			MusicID = null;
		}


		public override void OnEnter()
		{
			ANAMusic.pause(MusicID.Value);
			Finish();
		}
	}
}
