/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Sets the volume on this music.")]
	public class ANAMusicSetVolume : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("Left volume scalar (0.0 to 1.0).  If Right Volume is -1, this value will be used for both.")]
		[RequiredField]
		public FsmFloat LeftVolume = 0.5f;

		[Tooltip("Right volume scalar (0.0 to 1.0) If this is -1, defaults to Left Volume.")]
		[RequiredField]
		public FsmFloat RightVolume = -1;


		public override void Reset()
		{
			MusicID = null;
			LeftVolume = 0.5f;
			RightVolume = -1;
		}
		

		public override void OnEnter()
		{
			ANAMusic.setVolume(MusicID.Value, LeftVolume.Value, RightVolume.Value);
			Finish();
		}
	}
}
