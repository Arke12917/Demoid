/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Sets whether or not the music will play when the game is inactive.")]
	public class ANAMusicSetPlayInBackground : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("If true, the music will continue playing when the game is not active.  If false, the music will be paused when the game is not active and resumed when it becomes active again.")]
		[RequiredField]
		public FsmBool PlayInBackground;


		public override void Reset()
		{
			MusicID = null;
			PlayInBackground = null;
		}
		

		public override void OnEnter()
		{
			ANAMusic.setPlayInBackground(MusicID.Value, PlayInBackground.Value);
			Finish();
		}
	}
}
