/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Gets the duration of the file.")]
	public class ANAMusicGetDuration : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The duration in milliseconds.")]
		[RequiredField]
		public FsmInt Duration;


		public override void Reset()
		{
			MusicID = null;
			Duration = null;
		}
		

		public override void OnEnter()
		{
			Duration.Value = ANAMusic.getDuration(MusicID.Value);
			Finish();
		}
	}
}
