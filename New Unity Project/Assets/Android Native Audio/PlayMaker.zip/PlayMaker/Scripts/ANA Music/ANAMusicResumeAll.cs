/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Resumes play of all music paused with the Pause All action.")]
	public class ANAMusicResumeAll : FsmStateAction
	{
		[UIHint(UIHint.Description)]
		public string Description = "Resumes play of all music paused with the Pause All action.";


		public override void OnEnter()
		{
			ANAMusic.resumeAll();
			Finish();
		}
	}
}
