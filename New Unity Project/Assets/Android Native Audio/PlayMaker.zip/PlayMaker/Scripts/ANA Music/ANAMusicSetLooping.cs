/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Sets the music to be looping or non-looping.")]
	public class ANAMusicSetLooping : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("Whether to loop or not.")]
		[RequiredField]
		public FsmBool Looping;


		public override void Reset()
		{
			MusicID = null;
			Looping = null;
		}
		

		public override void OnEnter()
		{
			ANAMusic.setLooping(MusicID.Value, Looping.Value);
			Finish();
		}
	}
}
