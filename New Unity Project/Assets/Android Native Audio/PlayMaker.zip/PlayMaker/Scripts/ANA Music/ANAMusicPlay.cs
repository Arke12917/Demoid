/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


using System;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Starts or resumes playback.")]
	public class ANAMusicPlay : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;

		[Tooltip("An event to call when the playback has completed.")]
		public FsmEvent CompletionEvent;

		[Tooltip("Optional GameObject with an AudioSource to play in non-Android environments.")]
		public FsmGameObject AlternateAudio;


		public override void Reset()
		{
			MusicID = null;
			AlternateAudio = null;
			CompletionEvent = null;
		}


		public override void OnEnter()
		{
			Action<int> callback = null;
			if (CompletionEvent != null)
				callback = OnCompletion;

#if UNITY_ANDROID && !UNITY_EDITOR
			ANAMusic.play(MusicID.Value, callback);
#else
			if (AlternateAudio.Value != null)
			{
				var audioSource = AlternateAudio.Value.GetComponent<AudioSource>();
				if (audioSource != null)
					audioSource.Play();
				else
					Debug.LogError("ANA Music: Alternate audio missing, specified GameObject has no AudioSource component.", AlternateAudio.Value);
			}
			else
			{
				ANAMusic.play(MusicID.Value, callback);
			}
#endif
			Finish();
		}


		public void OnCompletion(int musicID)
		{
			MusicID.Value = musicID;
			Fsm.Event(CompletionEvent);
		}
	}
}
