/*
 *  Android Native Audio Music
 *
 *  Copyright 2016 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio Music")]
	[Tooltip("Releases resources associated with this music file.")]
	public class ANAMusicRelease : FsmStateAction
	{
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the music file to use.")]
		[RequiredField]
		public FsmInt MusicID;


		public override void Reset()
		{
			MusicID = null;
		}


		public override void OnEnter()
		{
			if (ANAMusic.isPlaying(MusicID.Value))
				ANAMusic.pause(MusicID.Value);
			ANAMusic.release(MusicID.Value);
			Finish();
		}
	}
}
