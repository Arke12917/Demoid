/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Releases the audio pool resources.")]
	public class AndroidNativeAudioReleasePool : FsmStateAction
	{
		[UIHint(UIHint.Description)]
		public string Description = "Releases the audio pool resources.";


		public override void OnEnter()
		{
			AndroidNativeAudio.releasePool();
			Finish();
		}
	}
}
