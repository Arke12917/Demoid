/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Stops a stream.")]
	public class AndroidNativeAudioStop : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to stop.")]
		public FsmInt streamID;

		public override void Reset()
		{
			streamID = null;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.stop(streamID.Value);
			Finish();
		}
	}
}
