/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Resumes all streams paused with the Pause All action.")]
	public class AndroidNativeAudioResumeAll : FsmStateAction
	{
		[UIHint(UIHint.Description)]
		public string Description = "Resumes all streams paused with the Pause All action.";


		public override void OnEnter()
		{
			AndroidNativeAudio.resumeAll();
			Finish();
		}
	}
}
