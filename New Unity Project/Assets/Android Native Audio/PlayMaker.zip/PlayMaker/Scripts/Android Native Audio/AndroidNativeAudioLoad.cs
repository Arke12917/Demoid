/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


using System;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Loads an audio file.  Returns the file ID.  Use 'Make Pool' before loading.")]
	public class AndroidNativeAudioLoad : FsmStateAction
	{
        [Tooltip("The path to the sound file, relative to Assets\\StreamingAssets.")]
		[Title("Audio File")]
		[RequiredField]
		public FsmString soundFile;

		[Tooltip("If true, Audio File is relative to Application.persistentDataPath.  If false, it is relative to Assets\\StreamingAssets.")]
		[RequiredField]
		public FsmBool usePersistentDataPath = false;

		[Tooltip("An event to call when the load has completed.")]
		public FsmEvent LoadedEvent;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the loaded file.  Use with 'Play' and 'Unload'.")]
		[Title("File ID")]
		[RequiredField]
		public FsmInt soundID;

		public override void Reset()
		{
			soundFile = null;
			usePersistentDataPath = false;
			LoadedEvent = null;
			soundID = null;
		}

		public override void OnEnter()
		{
			Action<int> callback = null;
			if (LoadedEvent != null)
				callback = OnLoaded;
			soundID.Value = AndroidNativeAudio.load(soundFile.Value, usePersistentDataPath.Value, callback);
			Finish();
		}


		public void OnLoaded(int soundID)
		{
			this.soundID.Value = soundID;
			Fsm.Event(LoadedEvent);
		}
	}
}
