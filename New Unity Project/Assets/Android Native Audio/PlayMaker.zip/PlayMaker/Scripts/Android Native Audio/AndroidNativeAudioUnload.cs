/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Unloads a file from the pool.  Returns the unload result.")]
	public class AndroidNativeAudioUnload : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the file to unload.")]
		[Title("FileID")]
		public FsmInt soundID;

		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The unload result.  True if unloaded, false if previously unloaded.")]
		public FsmBool result;

		public override void Reset()
		{
			soundID = null;
			result = null;
		}

		public override void OnEnter()
		{
			result.Value = AndroidNativeAudio.unload(soundID.Value);
			Finish();
		}
	}
}
