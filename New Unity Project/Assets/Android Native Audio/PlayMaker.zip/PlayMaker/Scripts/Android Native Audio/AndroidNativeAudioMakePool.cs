/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Makes an Android native audio pool.")]
	public class AndroidNativeAudioMakePool : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The maximum number of streams.  (The maximum number of simultaneously playing files.)")]
		public FsmInt maxStreams = 16;

		public override void Reset()
		{
			maxStreams = 16;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.makePool(maxStreams.Value);
			Finish();
		}
	}
}
