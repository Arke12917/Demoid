/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Plays a file.  Returns the stream played on.  Use 'Load' before playing.")]
	public class AndroidNativeAudioPlay : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the file to play.")]
		[Title("File ID")]
		public FsmInt soundID;

		[RequiredField]
		[Tooltip("The left volume to play at (0.0 - 1.0).  Set Right Volume to -1 to use this value for both.")]
		public FsmFloat leftVolume = 1;

		[RequiredField]
		[Tooltip("The right volume to play at (0.0 - 1.0).  Set to -1 to use Left Volume for both.")]
		public FsmFloat rightVolume = -1;

		[RequiredField]
		[Tooltip("The priority of this stream.  If the number of simultaneously playing streams exceeds 'Max Playing' in 'Make Pool', higher priority streams will play and lower priority streams will not.")]
		public FsmInt priority = 1;

		[RequiredField]
		[Tooltip("How many times to loop the audio.  A value of 0 will play once, -1 will loop until stopped.")]
		public FsmInt loop = 0;

		[RequiredField]
		[Tooltip("The rate to play at.  A value of 0.5 will play at half speed, 2 will play at double speed.")]
		public FsmFloat rate = 1;

		[Tooltip("Optional GameObject with an AudioSource to play in non-Android environments.  Uses 'Left Volume' for volume.")]
		public FsmGameObject alternateAudio;
		
		[ActionSection("Returns")]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream the sound is playing on.  Use with 'Pause', 'Resume', etc.")]
		public FsmInt streamID;

		public override void Reset()
		{
			soundID = null;
			leftVolume = 1;
			rightVolume = -1;
			priority = 1;
			loop = 0;
			rate = 1;
			alternateAudio = null;
			streamID = null;
		}

		public override void OnEnter()
		{
#if UNITY_ANDROID && !UNITY_EDITOR
			streamID.Value = AndroidNativeAudio.play(soundID.Value, leftVolume.Value, rightVolume.Value, priority.Value, loop.Value, rate.Value);
#else
			if (alternateAudio.Value != null)
			{
				AudioSource audioSource = alternateAudio.Value.GetComponent<AudioSource>();
				if (audioSource != null)
				{
					audioSource.volume = leftVolume.Value;
					audioSource.Play();
				}
				else
					Debug.LogError("Android Native Audio: Alternate audio missing, specified GameObject has no AudioSource component.", alternateAudio.Value);
			}
			else
			{
				streamID.Value = AndroidNativeAudio.play(soundID.Value, leftVolume.Value, rightVolume.Value, priority.Value, loop.Value, rate.Value);
			}
#endif
			Finish();
		}
	}
}
