/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Sets the rate of a stream.")]
	public class AndroidNativeAudioSetRate : FsmStateAction
	{
		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("The ID of the stream to change.")]
		public FsmInt streamID;

		[RequiredField]
		[Tooltip("The rate to play at.  A value of 0.5 will play at half speed, 2 will play at double speed.")]
		public FsmFloat rate = 1;

		public override void Reset()
		{
			streamID = null;
			rate = 1;
		}

		public override void OnEnter()
		{
			AndroidNativeAudio.setRate(streamID.Value, rate.Value);
			Finish();
		}
	}
}
