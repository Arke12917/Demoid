/*
 *  Android Native Audio
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Android Native Audio.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("Android Native Audio")]
	[Tooltip("Pauses all playing streams.  Use the Resume All action to resume.")]
	public class AndroidNativeAudioPauseAll : FsmStateAction
	{
		[UIHint(UIHint.Description)]
		public string Description = "Pauses all playing streams.  Use the Resume All action to resume.";


		public override void OnEnter()
		{
			AndroidNativeAudio.pauseAll();
			Finish();
		}
	}
}
